package fr.eclipseteam.scrimer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrimerApplicationTests {

	@Test
	void contextLoads() {
	}

}
